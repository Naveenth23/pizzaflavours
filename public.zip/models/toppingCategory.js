class ToppingCategory {
    constructor(id, toppingCategoryName ) {
            this.id = id;
            this.toppingCategoryName = toppingCategoryName;
    }
}

module.exports = ToppingCategory;