class Ingredient {
    constructor(id, ingredientName) {
            this.id = id;
            this.ingredientName = ingredientName;
    }
}

module.exports = Ingredient;